
 MICHAELA AGPALZA ARTEFACTS FOR SPRINT 2

 1. CHAT CHANNEL CHANGES AND TEST CASES 		LOCATION: Chat Channel changes, test cases, integration and def function (pushers changed to CRC (chat)).docx
 
 2. CHAT CHANNEL INTEGRATION				LOCATION: Chat Channel changes, test cases, integration and def function (pushers changed to CRC (chat)).docx

 3. CHAT CHANNEL DEF FUNCTION				LOCATION: Chat Channel changes, test cases, integration and def function (pushers changed to CRC (chat)).docx

 4. MEETING MINUTES					LOCATION: Sprint 2_Meeting Minutes (CSIS - Team 65).docx

 5. ERD MODEL 						LOCATION: ERD Model for CRC Database.docx

 6. PETRI - NET						LOCATION: Petri-Net for Customer Interface.PNG
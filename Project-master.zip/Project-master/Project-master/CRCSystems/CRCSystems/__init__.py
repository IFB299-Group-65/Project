"""
Package for CRCSystems.
"""

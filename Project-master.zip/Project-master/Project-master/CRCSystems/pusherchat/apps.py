from django.apps import AppConfig


class PusherchatConfig(AppConfig):
    name = 'pusherchat'
